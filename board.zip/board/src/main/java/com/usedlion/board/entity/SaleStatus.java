package com.usedlion.board.entity;
public enum SaleStatus { ONSALE, RESERVED, SOLDOUT }
